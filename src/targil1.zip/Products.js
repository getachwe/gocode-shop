import './Product.css';
import Product from './Product';
function Products(){
    return(
       <div> <Product/></div>
    );
}
export default Products;